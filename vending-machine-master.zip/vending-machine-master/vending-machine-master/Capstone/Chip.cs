﻿namespace Capstone
{
    using System;
    using System.Collections.Generic;
    using System.Text;

    public class Chip : VendingItem
    {
        public const string Message = "Enjoy Your Chips!";

        public Chip(
            string productName,
            decimal price,
            int itemsRemaining)
                : base(
                productName,
                price,
                itemsRemaining,
                Message)
        {
        }
    }
}
